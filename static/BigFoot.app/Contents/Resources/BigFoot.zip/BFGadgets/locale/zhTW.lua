local L = LibStub("AceLocale-3.0"):NewLocale("BFGadgets", "zhTW")
if not L then return end

L["Node %d"] = "節點 %d";
L["Map Note"] = "地圖標記";
L["%s has been set, the coordinate is (%d, %d)."] = "%s已經被設置，座標為：(%d, %d)。";
L["Coord Window"] = "座標顯示器";
L["Left click to move window.\nShift + Left click to set a mark.\nShift + Right click to reset position."] = "左鍵點擊可以拖動視窗。\nShift+左鍵點擊可以設置地圖座標。\nShift+右鍵點擊可以重置視窗位置。";
L["System Volume Control"] = "系統聲音設置"

if GetLocale()=='zhTW' then
	BFVOLUME_GAMETOOLTIP = "提供系統聲音設置"
end