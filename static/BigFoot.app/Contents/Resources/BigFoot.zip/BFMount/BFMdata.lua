
BFMData={
[49193]=true,
[60024]=true,
[71810]=true,
[37015]=true,
[63963]=true,
[67336]=true,
[40192]=true,
[59976]=true,
[72808]=true,
[58615]=true,
[64927]=true,
[65439]=true,
[72807]=true,
[63956]=true,
[44744]=true,
[63796]=true,
[69395]=true,
[32345]=true,
[60021]=true

}  --��������

