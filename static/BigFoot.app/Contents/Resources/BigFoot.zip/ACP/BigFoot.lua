--Terry@BF created 11-9-1
if GetLocale()=='zhCN' then
	ACP_BF_BUTTON = "插件管理"
elseif GetLocale() =='zhTW' then
	ACP_BF_BUTTON = "插件管理"
else
	ACP_BF_BUTTON = "ACP"
end
--Terry@bf 调整相关位置

local _G = _G
GameMenuButtonAddOns:SetScript("OnShow",function() end)
GameMenuFrame:HookScript("OnShow",function()
	if _G.BigFootMenuButtonOptions then
		_G.GameMenuButtonAddOns:ClearAllPoints();
		_G.GameMenuButtonAddOns:SetPoint("TOP", "BigFootMenuButtonOptions", "BOTTOM", 0, -1);
		_G.GameMenuButtonHelp:SetPoint("TOP", "GameMenuButtonAddOns", "BOTTOM", 0, -1);
		_G.GameMenuButtonOptions:SetPoint("TOP", "GameMenuButtonHelp", "BOTTOM", 0, -1);
		GameMenuFrame:SetHeight(GameMenuFrame:GetHeight()+25);
	else
		_G.GameMenuButtonAddOns:ClearAllPoints();
		_G.GameMenuButtonAddOns:SetPoint("CENTER", "GameMenuFrame", "TOP", 0, -37);
		_G.GameMenuButtonHelp:SetPoint("TOP", "GameMenuButtonAddOns", "BOTTOM", 0, -1);
		_G.GameMenuButtonOptions:SetPoint("TOP", "GameMenuButtonHelp", "BOTTOM", 0, -1);
		GameMenuFrame:SetHeight(GameMenuFrame:GetHeight()+25);
	end
end)

--Terry@bf 对应大脚相关选项
local reverseTable=
{
	TrinketMenu 	= {"TrinketMenu","EnableTrinketMenu"},
	TheBurningTrade = {"TradeHelper","EnableTradeHelper"},
	SpellTimer 		= {"SpellTimer","EnableSpellTimer"},
	EventAlertMod 	= {"SpellMonitor","EnableEventAlert"},
	SellerHelper 	= {"SellerHelper","EnableSellerHelper"},
	RepairHelper 	= {"EnableRepairHelper","RepairHelper"},
	RaidAlerter 	= {"RaidToolkit","EnableRaidAlerter"},

	Omen 			= {"RaidToolkit","EnableThreat"},
	Decursive 		= {"RaidToolkit","EnableDecursive"},
	Grid 			= {"RaidToolkit","EnableGrid"},
	["DBM-Core"] 	= {"RaidToolkit","EnableDBM"},
	QuestHubber 	= {"QuestEnhancement","EnableQuestHubber"},
	Clique 			= {"PartyToolkit","EnableClique"},
	ezIcons 		= {"PartyToolkit","EnableezIcon"},
	BFMount 		= {"BFMount","EnableMountEnhance"},
	MobHealth 		= {"MobHealth","MobHealthEnable"},
	RatingBuster 	= {"InfoStat","RatingBuster"},
	QuickCompare 	= {"InfoStat","EnableQuickCompare"},
	MerInspect 		= {"InfoStat","EnableMerInspect"},
	BigFootMark		= {"MapToolkit","MapMarkEnable"},
	MapPlus 		= {"MapToolkit","EnableMapPlus"},
	Archy	 		= {"MapToolkit","EnableArchy"},
	BlizzMove		= {"InfoBox","EnableBlizzMove"},
	GDKP			= {"MiDKP","GDKPEnable"},
	dct				= {"CombatIndicator","EnableDCT"},
	Gladius			= {"ArenaMod","EnableProximo"},
	AutoEquip		= {"AutoEquip","EnableAutoEquip"},
	PackUpInventory	= {"BagIntegration","Enable_PUI"},
	BFTooltip		= {"BFTT","EnableBFTooltip"},
	MySlot			= {"BigFootGadget","EnableMySlot"},
	BFGadgets		= {"BigFootGadget","EnableBigFootGPS"},
	BFCastingBar	= {"BigFootGadget","BFCB"},
	MailMod			= {"BigFootGadget","EnableMailMod"},
	ReforgeLite		= {"InfoStat","EnableReforgeLite"},
	CoolLine		= {"ActionButton","EnableCoolLine"},
	Skada			= {"RaidToolkit","EnableSkada"},
	GladiatorlosSA	= {"ArenaMod","EnableGladiatorlosSA"},
}

function BigFoot_ReverseDisableModOptions(name,enable)

	if reverseTable[name] and BigFoot_SetModVariable then
		local modName,varName =unpack(reverseTable[name])
		BigFoot_SetModVariable(modName,varName,1);
	end
end

hooksecurefunc(ACP,"AddonList_LoadNow",function(_,index)
	local name = GetAddOnInfo(index)
	if BigFoot_ReverseDisableModOptions then
		BigFoot_ReverseDisableModOptions(name)
	end
end)

local f= CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent",function(...)
	local _,_,addOn = ...
	if addOn == "BigFoot" then
		if _G.ModManagementFrame then
			bf_acpButton = CreateFrame("Button","BF_ACPAddonButton",_G.ModManagementFrame,"UIPanelButtonTemplate")
			bf_acpButton:ClearAllPoints()
			bf_acpButton:SetText(ACP_BF_BUTTON)
			bf_acpButton:SetWidth(88)
			bf_acpButton:SetHeight(26)
			bf_acpButton:SetPoint("BOTTOMRIGHT",ModManagementFrame,"BOTTOMRIGHT",-205,35);
			bf_acpButton:Show()
			bf_acpButton:SetScript("OnClick",function()
				ShowUIPanel(ACP_AddonList);
				ModManagementFrame:Hide();
			end)
		end
		f:UnregisterAllEvents()
	end
end)
