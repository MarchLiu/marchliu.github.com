
local f = CreateFrame'Frame';
local pf = CreateFrame'Frame';
pf.timeStep = 0;

local events = {
	'ADDON_LOADED',
	'ZONE_CHANGED_NEW_AREA',
	'AREA_SPIRIT_HEALER_IN_RANGE',
	'AREA_SPIRIT_HEALER_OUT_OF_RANGE',
	-- 'UNIT_AURA',
	-- 'PLAYER_ALIVE',
	-- 'PLAYER_UNGHOST',
}

for _, event in pairs(events) do
	f:RegisterEvent(event);
end

if ( GetLocale() == "zhCN" ) then
	_SPIRITHEALTIME ="%s：%d秒"
	_SPIRITHEALTIME_ING ="%s：复活中..."
	BH_TOOLTIP = "Shift点击发送到战场频道"
	BH_ADD = "<大脚战场助手通知> *%s* 复活倒计时还有%d秒"
	_WARNING_TEXT = "<大脚战场助手通知> 距托尔巴拉德战斗开始还有>>%s<<分钟";
	_WARNING2_TEXT = "<大脚战场助手通知> 托尔巴拉德战斗即将开始。";
	_DYWARNING_TEXT = "<大脚战场助手通知> 距冬拥湖战斗开始还有>>%s<<分钟";
	_DYWARNING2_TEXT = "<大脚战场助手通知> 冬拥湖战斗即将开始。";
elseif (GetLocale() == "zhTW") then
	_SPIRITHEALTIME="%s：%d秒"
	_SPIRITHEALTIME_ING="%s：復活中..."
	BH_TOOLTIP = "Shift點擊發送到戰場頻道"
	BH_ADD = "<大腳戰場助手通知> *%s* 復活倒計時還有%d秒"
	_WARNING_TEXT = "<大腳戰場助手通知> 距托爾巴拉德戰鬥開始還有>>%s<<分鐘";
	_WARNING2_TEXT = "<大腳戰場助手通知> 托爾巴拉德战斗即將开始";
	_DYWARNING_TEXT = "<大腳戰場助手通知> 距冬握湖戰鬥開始還有>>%s<<分鐘";
	_DYWARNING2_TEXT = "<大腳戰場助手通知> 冬握湖战斗即將开始";
end

local BattleIDTable = {
	[401] = true,
	[443] = true,
	[461] = true,
	[482] = true,
	[512] = true,
	[540] = true,
	[626] = true,
	[736] = true,
}

local toggle_swith,toggle_swithWarning,toggle_swithDYWarning,can_reset
local isInstance, instanceType, isinBattle,isinAncients
local zoneText,lastTime,bf_time,cl_time

local function BH_update_Time()
	if toggle_swith ~= 1 then BattleHapperPanel:Hide(); return end
	if WorldStateAlwaysUpFrame then
		zoneText = GetMinimapZoneText();
		if GetAreaSpiritHealerTime() == 0 then
			BattleHapperPanelText:SetText(string.format(_SPIRITHEALTIME_ING, zoneText))
		else
			BattleHapperPanelText:SetText(string.format(_SPIRITHEALTIME, zoneText,floor(GetAreaSpiritHealerTime())))
		end
		BattleHapperPanel:SetPoint("TOP", "WorldStateAlwaysUpFrame", "TOP", 0, 5)
		BattleHapperPanel:Show()
	else
		BattleHapperPanel:Hide()
	end
end

local function BH_Calculation_Time()
	if toggle_swith ~= 1 then BattleHapperPanel:Hide(); return end
	if lastTime then
		bf_time = floor(GetTime() - lastTime)
		if bf_time >=31 then
			can_reset = true
			lastTime = GetTime()+0.3
		end

		if WorldStateAlwaysUpFrame then
			if zoneText then
				if bf_time <= 0 then
					BattleHapperPanelText:SetText(string.format(_SPIRITHEALTIME_ING, zoneText))
				else
					BattleHapperPanelText:SetText(string.format(_SPIRITHEALTIME, zoneText,abs(31-bf_time)))
				end
				BattleHapperPanel:Show()
			else
				BattleHapperPanel:Hide()
			end
		else
			BattleHapperPanel:Hide()
		end
	end
end

f:SetScript('OnEvent', function(self, event, ...)
	if (event == "ADDON_LOADED" and select(1,...) == "BattleHapper") or (event == "ZONE_CHANGED_NEW_AREA") then
		isInstance, instanceType = IsInInstance()
		if isInstance and instanceType == "pvp" then
			SetMapToCurrentZone()
			local currentMap = GetCurrentMapAreaID()
			if BattleIDTable[currentMap] then
				isinBattle =true;
				if currentMap == 512 then
					isinAncients =true
				end
			end
		else
			isinBattle = nil;
			isinAncients = nil;
			f:SetScript("OnUpdate", nil);
			BattleHapperPanel:Hide()
		end
		if event == "ADDON_LOADED" then
			local BattleHapper_SetHyperlink_Origin = ItemRefTooltip.SetHyperlink;
			ItemRefTooltip.SetHyperlink = function(self,link)
				if(strsub(link, 1, 12)=="BattleHapper") then return end
				return BattleHapper_SetHyperlink_Origin(self,link);
			end
			hooksecurefunc("SetItemRef", BattleHapper_SetItemRef);
		end
	-- else
		-- print(event)
	end
	if event == "UNIT_AURA" then
		local _unit = ...
		if ((strsub(_unit, 1, 4)=="raid") and can_reset) then
			for __i = 1, BUFF_MAX_DISPLAY do
				local __name, _, __texture, __count, _, __duration, __expirationTime, __caster,_,_,_spellId = UnitAura(_unit, __i, "HELPFUL|PLAYER");
				if _spellId == 44535 then
					print("reset")
					can_reset = nil
					lastTime = GetTime()
					return;
				end
			end
		end
	end
	if event == "AREA_SPIRIT_HEALER_IN_RANGE" then
		if isinBattle then
			if ( UnitIsGhost("player") ) then
				f:SetScript("OnUpdate", BH_update_Time)
			end
		end
	elseif event == "AREA_SPIRIT_HEALER_OUT_OF_RANGE" then
		lastTime = GetTime();
		f:SetScript("OnUpdate", BH_Calculation_Time)
	end
end)

function BattleHapper_OnMouseDown(self, button)
	if IsShiftKeyDown() and zoneText then
		local str
		if GetAreaSpiritHealerTime() ~=0 then
			str = string.format(BH_ADD, zoneText,floor(GetAreaSpiritHealerTime()))
		elseif bf_time and bf_time >=0 then
			str = string.format(BH_ADD, zoneText,abs(31-bf_time))
		end
		if str then
			SendChatMessage(str, "INSTANCE_CHAT");
		end
	end
end

function BattleHapperToggle(swith)
	toggle_swith = swith
end

function BattleHapperToggle_warning(swith)
	toggle_swithWarning = swith
end

function BattleHapperToggle_DYwarning(swith)
	toggle_swithDYWarning = swith
end

local WARNING_TEXT_Table = {
	[101] = _DYWARNING2_TEXT,
	[105] = string.format(_DYWARNING_TEXT, 5),
	[1010] = string.format(_DYWARNING_TEXT, 10),
	[1015] = string.format(_DYWARNING_TEXT, 15),
	[201] = _WARNING2_TEXT,
	[205] = string.format(_WARNING_TEXT, 5),
	[2010] = string.format(_WARNING_TEXT, 10),
	[2015] = string.format(_WARNING_TEXT, 15),
}

local warning1,warning2,warning3,warning4
local _warning1,_linkString1,_warning2,_linkString2

pf:SetScript("OnUpdate", function(self, elapsed)
	if not IsInInstance() then
		self.timeStep = self.timeStep + elapsed;
		if self.timeStep > WORLD_PVP_TIME_UPDATE_IINTERVAL then
			self.timeStep = 0;
			if toggle_swithWarning then
				local _, name, isActive, canQueue, startTime, canEnter = GetWorldPVPAreaInfo(2);	--isActive,是否正在进行中 canQueue，是否可排队
				if canEnter and canQueue then
					if floor(startTime)==898 then
						_warning1 = string.format(_WARNING_TEXT, 15)
						_linkString1 = "|CFF00B4FF|HBattleHapper:2015|h[发送提示]|h|r";
						warning1 = true;
					elseif floor(startTime) == 600 and not warning1 then
						_warning1 = string.format(_WARNING_TEXT, 10)
						_linkString1 = "|CFF00B4FF|HBattleHapper:2010|h[发送提示]|h|r";
					elseif floor(startTime) == 300 then
						_warning1 = string.format(_WARNING_TEXT, 5)
						_linkString1 = "|CFF00B4FF|HBattleHapper:205|h[发送提示]|h|r";
						warning2 = true;
					elseif floor(startTime) < 300 and not warning2 then
						_warning1 = _WARNING2_TEXT
						_linkString1 = "|CFF00B4FF|HBattleHapper:201|h[发送提示]|h|r";
						warning2 = true;
					end
					if _warning1 and _linkString1 then
						_warning1 = _warning1 .. _linkString1;
						DEFAULT_CHAT_FRAME:AddMessage(_warning1, 1, 0.9, 0.4);
						_warning1,_linkString1 = nil,nil
					end
				else
					warning1,warning2 = nil,nil
				end
			end
			if toggle_swithDYWarning then
				local _, name, isActive, canQueue, startTime, canEnter = GetWorldPVPAreaInfo(1);	--isActive,是否正在进行中 canQueue，是否可排队
				if canEnter and canQueue then
					if floor(startTime)==898 then
						_warning2 = string.format(_DYWARNING_TEXT, 15)
						_linkString2 = "|CFF00B4FF|HBattleHapper:1015|h[发送提示]|h|r";
						warning3 = true;
					elseif floor(startTime) == 600 and not warning3 then
						_warning2 = string.format(_DYWARNING_TEXT, 10)
						_linkString2 = "|CFF00B4FF|HBattleHapper:1010|h[发送提示]|h|r";
					elseif floor(startTime) == 300 then
						_warning2 = string.format(_DYWARNING_TEXT, 5)
						_linkString2 = "|CFF00B4FF|HBattleHapper:105|h[发送提示]|h|r";
						warning4 = true;
					elseif floor(startTime) < 300 and not warning4 then
						_warning2 = _DYWARNING2_TEXT
						_linkString2 = "|CFF00B4FF|HBattleHapper:101|h[发送提示]|h|r";
						warning4 = true;
					end
					if _warning2 and _linkString2 then
						_warning2 = _warning2 .. _linkString2;
						DEFAULT_CHAT_FRAME:AddMessage(_warning2, 1, 0.9, 0.4);
						_warning2,_linkString2 = nil,nil
					end
				else
					warning3,warning4 = nil,nil
				end
			end
		end
	end
end)

function BattleHapper_SetItemRef(link, text, button)
	if ( strsub(link, 1, 12) == "BattleHapper" ) then
		local id = 0+gsub(gsub(strsub(link,14),"/2","|"),"/1","/");
		if id then
			local message = WARNING_TEXT_Table[id]
			if IsInRaid() then
				SendChatMessage(message, "raid");
			elseif IsInGroup() then
				SendChatMessage(message, "party");
			elseif GetGuildInfo("PLAYER") then
				SendChatMessage(message, "GUILD");
			else
				SendChatMessage(message, "YELL");
			end
		end
	end
end;
--52459回合结束
--44535灵魂治疗